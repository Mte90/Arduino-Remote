Talk-OWA-App
============

![](screenshot.png)  
App Repo: <a href="https://github.com/Mte90/Talk-OWA-App">https://github.com/Mte90/Talk-OWA-App</a>

![](foto.jpg)  
Sketch: <a href="https://gist.github.com/Mte90/ba94ae6f383afda71b13">https://gist.github.com/Mte90/ba94ae6f383afda71b13</a>