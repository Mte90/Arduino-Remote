Arduino-Remote
============

![](screenshot.png)  
App Repo: <a href="https://github.com/Mte90/Arduino-Remote">https://github.com/Mte90/Arduino-Remote</a>

![](foto.jpg)  
aREST: <a href="http://arest.io/">http://arest.io</a>  

Install as Open Web App: <a href="https://mte90.github.io/Arduino-Remote/">https://mte90.github.io/Arduino-Remote/</a><br>

Thanks to Luca Ferroni, Michele Sorcinelli for the improvement for aREST app.